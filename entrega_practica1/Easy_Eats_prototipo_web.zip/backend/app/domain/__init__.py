"""Catalog and menu rules."""
