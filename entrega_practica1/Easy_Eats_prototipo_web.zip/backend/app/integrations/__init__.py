"""Interchangeable monthly menu generators."""
